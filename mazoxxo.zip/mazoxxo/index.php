<?php
	ini_set('display_errors','On');
	error_reporting(E_ALL);

	require_once("php/mysql.php");

	$mysql = new MySQLPDO();
    
	$mysql->connect();

    $mensaje = "";
    
    if(isset($_POST['action'])){
        switch($_POST['action']){
            case 'eliminar':    
                            $id=$_POST['id'];
                            $query="DELETE FROM clientes WHERE id=?";
                            $mysql->execute($query,array($id));
                            $mensaje = "Eliminado";
                            break;                            
        }
    }

    

    if(isset($_POST['nombre'])){
        //insert
        $nombre = $_POST['nombre'];
        $apellido_paterno = $_POST['apellido_paterno'];
        $apellido_materno = $_POST['apellido_materno'];
        $query="INSERT INTO clientes (nombre,apellido_paterno,apellido_materno) VALUES (?,?,?)";
        $mysql->execute($query,array($nombre,$apellido_paterno,$apellido_materno));    

        $mensaje="Registro guardado correctamente.";

    }
    
    $query="SELECT * FROM clientes";
	$resultados = $mysql->execute($query);
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Shop Item - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <form action="" method="post">
        <div class="modal fade" tabindex="-1" role="dialog" id="myModal">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Nuevo Cliente</h4>
              </div>
              <div class="modal-body">
                    
                        <div class="form-group">
                            <label for="txtNombre">Nombre</label>
                            <input type="text" name="nombre" class="form-control" id="txtNombre" placeholder="Nombre">
                        </div>
                        <div class="form-group">
                            <label for="txtApellidoPaterno">Apellido Paterno</label>
                            <input type="text"  name="apellido_paterno" class="form-control" id="txtApellidoPaterno" placeholder="A">
                        </div>
                        <div class="form-group">
                            <label for="txtApellidoMaterno">Apellido Materno</label>
                            <input type="text" name="apellido_materno" class="form-control" id="txtApellidoMaterno" placeholder="Nombre">
                        </div>                                            
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                <button type="submit" class="btn btn-success">Guardar</button>
              </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
    </form>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Start Bootstrap</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="#">About</a>
                    </li>
                    <li>
                        <a href="#">Services</a>
                    </li>
                    <li>
                        <a href="#">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>    

    <!-- Page Content -->
    <div class="container">

        <div class="row">
            <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                  Nuevo Cliente
            </button>

        </div>

        <div class="row">

            <table id="tabla" class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Apellido Paterno</th>
                        <th>Apellido Materno</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    foreach($resultados as $resultado){  
                        $id = $resultado['id'];  
                ?>
                    <tr>
                        <td><?=$id;?></td>
                        <td><?=$resultado['nombre'];?></td>
                        <td><?=$resultado['apellido_paterno'];?></td>
                        <td><?=$resultado['apellido_materno'];?></td> 
                        <td>
                            <a href="#" style="margin-right:20px;"><span class="glyphicon glyphicon-pencil"></span></a>
                            <a href="javascript:eliminar(<?=$id?>);"><span class="glyphicon glyphicon-remove"></a>
                            <form id="eliminar_<?=$id?>" action="" method="post">
                                <input type="hidden" name="action" value="eliminar">
                                <input type="hidden" name="id" value="<?=$id?>">
                            </form>
                        </td>                       
                    </tr>
                <?php
                    }
                ?>
                </tbody>
            </table>

        </div>

    </div>
    <!-- /.container -->

    <div class="container">

        <hr>

        <!-- Footer -->
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright &copy; Your Website 2014</p>
                </div>
            </div>
        </footer>

    </div>
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <script src="js/jquery.dataTables.js"></script>

    <script src="js/notify.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <script>
        function eliminar(id){
            var r = confirm ("Estas seguro que deseas eliminar el registro "+id+"? ");

            if(r == true){
                $('#eliminar_'+id).submit();
            }
        }


        $('#tabla').DataTable();


        <?php
            if(strlen($mensaje) > 1){
        ?>
                $.notify("<?=$mensaje;?>");
        <?php
            }
        ?>

    </script>

</body>

</html>










